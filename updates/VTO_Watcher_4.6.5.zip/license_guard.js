(() => {
  "use strict";

  const LOCK_ID = "vto-license-lock";
  let watcherTimer = null;

  function message(type, payload = {}) {
    return chrome.runtime.sendMessage({ type, ...payload });
  }

  function reasonText(status) {
    if (!status) return "License required.";
    switch (status.reason) {
      case "setup_required":
        return "Owner setup required: license server URL is not configured.";
      case "not_activated":
        return "License required. Click the extension icon to activate.";
      case "expired":
        return "This license has expired.";
      case "revoked":
        return "This license was revoked by the owner.";
      case "device_limit":
        return "This license has reached its device limit.";
      case "server_unreachable":
        return "License server could not be reached.";
      case "update_required":
        return status.message || "This extension version is no longer allowed. Update required.";
      case "version_not_allowed":
        return status.message || "Your license does not include access to this version.";
      default:
        return status.message || "License is not active.";
    }
  }

  function showLock(status) {
    let box = document.getElementById(LOCK_ID);
    if (!box) {
      box = document.createElement("div");
      box.id = LOCK_ID;
      box.innerHTML = `
        <div class="vto-lock-head">
          <div class="vto-lock-mark">V</div>
          <div class="vto-lock-title">VTO Watcher</div>
        </div>
        <div id="vto-license-lock-text"></div>
        <div class="vto-lock-note">Activate from the extension icon.</div>
      `;
      document.documentElement.appendChild(box);
    }

    const text = box.querySelector("#vto-license-lock-text");
    if (text) text.textContent = reasonText(status);
  }

  function hideLock() {
    document.getElementById(LOCK_ID)?.remove();
  }

  async function status(force = false) {
    try {
      return await message("licenseStatus", { force });
    } catch (_) {
      return {
        valid: false,
        reason: "server_unreachable",
        message: "License service unavailable."
      };
    }
  }

  async function requireValid(force = true) {
    const result = await status(force);
    if (result?.valid) {
      hideLock();
    } else {
      showLock(result);
    }
    return result;
  }

  async function waitForValid() {
    let result = await requireValid(true);
    if (result.valid) return true;

    return await new Promise(resolve => {
      const timer = setInterval(async () => {
        result = await requireValid(true);
        if (result.valid) {
          clearInterval(timer);
          resolve(true);
        }
      }, 5000);
    });
  }

  function startWatch(onInvalid) {
    if (watcherTimer) clearInterval(watcherTimer);

    watcherTimer = setInterval(async () => {
      const result = await status(true);
      if (!result.valid) {
        showLock(result);
        try {
          await onInvalid?.(result);
        } catch (_) {}
      } else {
        hideLock();
      }
    }, 5 * 60 * 1000);
  }

  window.VTOLicense = {
    status,
    requireValid,
    waitForValid,
    startWatch,
    showLock,
    hideLock
  };
})();
