const $ = id => document.getElementById(id);
const messageEl=$("message"), activateBox=$("activateBox"), activeBox=$("activeBox"), keyInput=$("licenseKey"), activateBtn=$("activateBtn"), deactivateBtn=$("deactivateBtn"), openBtn=$("openBtn"), expiresEl=$("expires"), labelEl=$("licenseLabel"), deviceEl=$("device"), versionAccessEl=$("versionAccess"), currentVersionEl=$("currentVersion");
const updateBox=$("updateBox"), updateHeading=$("updateHeading"), updateText=$("updateText"), updateBtn=$("updateBtn"), noUpdateUrl=$("noUpdateUrl"), copyStepsBtn=$("copyStepsBtn");
let currentUpdateUrl=null;
currentVersionEl.textContent=chrome.runtime.getManifest().version;

const UPDATE_STEPS=["VTO Watcher manual update:","1. Download the update ZIP.","2. Extract it.","3. Replace the files in your VTO extension folder.","4. Open chrome://extensions.","5. Press Reload on VTO Watcher.","6. Open the extension and confirm the new version is shown."].join("\n");

function setMessage(text,state="loading"){
  messageEl.textContent=text;
  messageEl.dataset.state=state;
}
function formatExpiry(value){if(!value)return"No expiration";const d=new Date(value);return Number.isNaN(d.getTime())?String(value):d.toLocaleDateString()+" "+d.toLocaleTimeString();}
function showUpdate(status){
  const required=Boolean(status?.updateRequired)||status?.reason==="update_required";
  const available=required||Boolean(status?.updateAvailable);
  if(!available){updateBox.classList.add("hidden");updateBox.classList.remove("required");currentUpdateUrl=null;return;}
  updateBox.classList.remove("hidden");updateBox.classList.toggle("required",required);
  updateHeading.textContent=required?"UPDATE REQUIRED":"UPDATE AVAILABLE";
  const parts=[];if(status.latestVersion)parts.push(`Latest: v${status.latestVersion}.`);parts.push(status.updateMessage||(required?"This version has been disabled by the owner.":"A newer VTO Watcher version is available."));
  updateText.textContent=parts.join(" ");currentUpdateUrl=status.updateUrl||null;updateBtn.classList.toggle("hidden",!currentUpdateUrl);noUpdateUrl.classList.toggle("hidden",Boolean(currentUpdateUrl));
}
async function refreshStatus(force=true){
  setMessage("Checking license…","loading");activateBtn.disabled=true;deactivateBtn.disabled=true;openBtn.disabled=true;
  try{
    const status=await chrome.runtime.sendMessage({type:"licenseStatus",force});showUpdate(status);
    if(status.valid){activateBox.classList.add("hidden");activeBox.classList.remove("hidden");setMessage(status.offlineGrace?"License active — temporary offline grace":"License active",status.offlineGrace?"warning":"success");expiresEl.textContent=formatExpiry(status.expiresAt);labelEl.textContent=status.label||"Active";deviceEl.textContent=(status.deviceId||"").slice(0,8)||"—";const maxMajor=Number(status.maxMajorVersion||4);versionAccessEl.textContent=maxMajor>=99?"All future":`Through V${maxMajor}`;}
    else{activeBox.classList.add("hidden");activateBox.classList.remove("hidden");if(status.reason==="expired")setMessage("License expired","error");else if(status.reason==="update_required")setMessage(status.message||"Update required","warning");else if(status.reason==="version_not_allowed")setMessage(status.message||"This license does not include this version","error");else if(status.reason==="setup_required")setMessage("Owner setup required","error");else setMessage(status.message||"This device has not been activated.","warning");}
  }catch(err){activeBox.classList.add("hidden");activateBox.classList.remove("hidden");setMessage(`License check failed: ${err.message||err}`,"error");}
  finally{activateBtn.disabled=false;deactivateBtn.disabled=false;openBtn.disabled=false;}
}
activateBtn?.addEventListener("click",async()=>{const key=keyInput.value.trim();if(!key){setMessage("Enter a license key.","warning");return;}activateBtn.disabled=true;activateBtn.textContent="Activating…";setMessage("Activating…","loading");try{const result=await chrome.runtime.sendMessage({type:"activateLicense",key});showUpdate(result);if(!result.ok||!result.valid){setMessage(result.message||"Activation failed.","error");return;}keyInput.value="";await refreshStatus(false);}finally{activateBtn.disabled=false;activateBtn.textContent="Activate";}});
keyInput?.addEventListener("keydown",e=>{if(e.key==="Enter")activateBtn.click();});
deactivateBtn?.addEventListener("click",async()=>{deactivateBtn.disabled=true;deactivateBtn.textContent="Deactivating…";setMessage("Deactivating…","loading");try{await chrome.runtime.sendMessage({type:"deactivateLicense"});await refreshStatus(false);}finally{deactivateBtn.disabled=false;deactivateBtn.textContent="Deactivate";}});
openBtn?.addEventListener("click",()=>chrome.tabs.create({url:"https://atoz.amazon.work/"}));
updateBtn?.addEventListener("click",()=>{if(currentUpdateUrl)chrome.tabs.create({url:currentUpdateUrl});});
copyStepsBtn?.addEventListener("click",async()=>{try{await navigator.clipboard.writeText(UPDATE_STEPS);copyStepsBtn.textContent="Copied";setTimeout(()=>copyStepsBtn.textContent="Copy update steps",1500);}catch{copyStepsBtn.textContent="Could not copy";}});
refreshStatus(true);
