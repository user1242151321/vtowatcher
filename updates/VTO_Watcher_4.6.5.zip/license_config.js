const LICENSE_CONFIG = {
  // Replace this with YOUR deployed Worker URL, for example:
  // https://vto-license-server.your-subdomain.workers.dev
  SERVER_URL: "https://vto-license-server.vto-license-ks.workers.dev",

  // Re-check a valid license with your server every 30 minutes.
  VALIDATE_EVERY_MS: 30 * 60 * 1000,

  // If your server is temporarily unreachable, an already-valid device
  // may keep working for up to 2 hours after its last successful check.
  OFFLINE_GRACE_MS: 2 * 60 * 60 * 1000
};