(() => {
  'use strict';
  if (window.VTOSessionGuard) return;
  const R = window.VTOReliability;
  let lastClick = -Infinity, lastNotice = -Infinity, previous = '', pending = false, attempts = 0;
  const guard = window.VTOSessionGuard = {blocked: false, check};
  function record(reason) { R.event('SESSION', reason); }
  function check() {
    if (!window.document?.documentElement) return {kind: 'CLEAR'};
    const s = R.session();
    guard.blocked = s.kind !== 'CLEAR';
    if (s.kind !== previous) {
      record(s.kind);
      if (s.kind === 'CLEAR') {
        if (pending) record('PROMPT_DISMISSED');
        pending = false; attempts = 0;
      }
      previous = s.kind;
    }
    if (s.kind === 'AUTH_REQUIRED') {
      if (Date.now() - lastNotice >= 60000) {
        lastNotice = Date.now();
        chrome.runtime.sendMessage({type: 'notify', title: 'VTO Watcher', message: 'Amazon sign-in or verification required. VTO actions and refresh are paused; sign in manually.'}).catch(() => {});
      }
      return s;
    }
    if (s.kind !== 'PROMPT') return s;
    if (!s.button) { if (!pending) record('SAFE_CONTROL_MISSING'); pending = true; return s; }
    if (Date.now() - lastClick < 4000) return s;
    if (attempts >= 3) {
      if (Date.now() - lastNotice >= 60000) {
        lastNotice = Date.now(); record('CONTINUATION_UNRESOLVED');
        chrome.runtime.sendMessage({type: 'notify', title: 'VTO Watcher', message: 'Amazon session prompt is still open after continuation attempts. Please check A to Z.'}).catch(() => {});
      }
      return s;
    }
    lastClick = Date.now(); attempts++; pending = true;
    try {
      if (R.authRequired() || !R.enabled(s.button)) return s;
      record('CONTINUE_CLICK'); s.button.click();
    } catch (_) { record('CONTINUE_CLICK_ERROR'); }
    return s;
  }
  let queued = false;
  const observer = new MutationObserver(records => {
    if (queued || records.every(r => (r.target.nodeType === 1 ? r.target : r.target.parentElement)?.closest?.('#vto-v4-panel'))) return;
    queued = true; setTimeout(() => { queued = false; check(); }, 50);
  });
  observer.observe(document.documentElement, {childList: true, subtree: true, characterData: true, attributes: true, attributeFilter: ['hidden','disabled','aria-disabled','aria-hidden','open']});
  setInterval(check, 400);
  check();
})();
