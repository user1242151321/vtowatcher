(() => {
  'use strict';
  if (window.VTOReliability) return;
  const norm = s => String(s || '').replace(/\s+/g, ' ').trim().toLowerCase();
  const parent = el => el.parentElement || el.getRootNode?.().host;
  function visible(el) {
    if (!(el instanceof Element) || !el.isConnected) return false;
    for (let p = el; p; p = parent(p)) {
      const s = getComputedStyle(p);
      if (p.hidden || p.inert || p.getAttribute('aria-hidden') === 'true' || s.display === 'none' || s.visibility === 'hidden' || s.opacity === '0') return false;
      if (p.id === 'vto-v4-panel') return false;
    }
    const r = el.getBoundingClientRect();
    return r.width > 0 && r.height > 0;
  }
  function query(selector, root = document) {
    const out = [...root.querySelectorAll(selector)];
    for (const el of root.querySelectorAll('*')) if (el.shadowRoot) out.push(...query(selector, el.shadowRoot));
    return out;
  }
  function text(el) {
    if (!el) return '';
    // Only visible page text; hidden historical states and our diagnostics are excluded.
    if (el.nodeType === 3) return el.textContent;
    if (el instanceof Element && !visible(el)) return '';
    return [...(el.shadowRoot || el).childNodes].map(text).join(' ');
  }
  function label(el) {
    const ids = el.getAttribute('aria-labelledby');
    return norm(el.getAttribute('aria-label') || (ids && ids.split(/\s+/).map(id => text(el.getRootNode().getElementById(id))).join(' ')) || text(el) || el.value || el.getAttribute('title'));
  }
  const selector = 'button,a[href],[role="button"],input[type="button"],input[type="submit"]';
  function enabled(el) {
    if (!visible(el) || el.disabled || el.matches(':disabled')) return false;
    for (let p = el; p; p = parent(p)) if (p.getAttribute('aria-disabled') === 'true') return false;
    return true;
  }
  function actions(root = document) {
    return [...new Set([...(root.matches?.(selector) ? [root] : []), ...query(selector, root)])].filter(enabled);
  }
  const rangeRE = /\b(\d{1,2}(?::\d{2})?\s*[ap]m)\s*[-–—−]\s*(\d{1,2}(?::\d{2})?\s*[ap]m)\b/ig;
  const ranges = t => [...String(t).matchAll(rangeRE)].map(m => norm(m[0]).replace(/[–—−]/g, '-'));
  function minutes(t) {
    const m = t.match(/(\d{1,2})(?::(\d{2}))?\s*([ap])m/i);
    if (!m || +m[1] < 1 || +m[1] > 12 || +(m[2] || 0) > 59) return null;
    return (+m[1] % 12) * 60 + +(m[2] || 0) + (m[3].toLowerCase() === 'p' ? 720 : 0);
  }
  function rangeInfo(t) {
    const m = [...String(t).matchAll(rangeRE)][0];
    if (!m) return null;
    const start = minutes(m[1]), end = minutes(m[2]);
    if (start === null || end === null || start === end) return null;
    return {startText: m[1], endText: m[2], startMinutes: start, hours: ((end - start + 1440) % 1440) / 60};
  }
  const direct = /^(accept|claim|take|get|request|apply)( vto| voluntary time off)?$/;
  const opener = /^(select|view|view details|details|open|review|choose|next|continue)( vto| voluntary time off| opportunity)?$/;
  const stale = /\b(vto filled|vto full|opportunity filled|no longer available|unavailable|expired|already accepted|previously accepted|you accepted|vto accepted)\b/;
  const dialogs = () => query('[role="dialog"],[role="alertdialog"],[aria-modal="true"],dialog,[class*="modal" i],[class*="dialog" i]').filter(visible);
  function actionFor(card) {
    const list = actions(card);
    const el = list.find(e => direct.test(label(e))) || list.find(e => opener.test(label(e))) || (enabled(card) && card.matches(selector) && ranges(text(card)).length === 1 ? card : null);
    return el ? {el, label: label(el)} : null;
  }
  function offers() {
    const seeds = query('div,section,article,li,span,p,time,button,[role="button"]').filter(visible).filter(el => !el.closest('[role="dialog"],[role="alertdialog"],[aria-modal="true"],dialog,form')).filter(el => ranges(text(el)).length === 1 && ![...el.children].some(c => ranges(text(c)).length));
    const cards = new Set();
    for (const seed of seeds) {
      let best = seed;
      for (let cur = seed, depth = 0; cur && cur !== document.body && depth < 12; cur = parent(cur), depth++) {
        const raw = text(cur);
        // Count occurrences, not unique strings: identical times on adjacent dates are distinct cards.
        if (ranges(raw).length !== 1 || raw.length > 2600 || cur.matches('[role="dialog"],[role="alertdialog"],dialog,form,main,nav')) break;
        best = cur;
        if (actionFor(cur)) break;
      }
      cards.add(best);
    }
    return [...cards].filter(card => ![...cards].some(other => other !== card && card.contains(other))).map(card => {
      const raw = text(card), r = rangeInfo(raw), action = actionFor(card), old = stale.test(norm(raw));
      // A contradictory card stays unknown; never borrow a neighboring action.
      const classification = old ? (action ? 'UNKNOWN' : 'OLD') : (r && action ? 'LIVE' : 'UNKNOWN');
      return {card, raw, ...r, hours: r?.hours || 0, location: '', unavailable: classification !== 'LIVE', classification, liveAction: !!action, staleLabel: old};
    });
  }
  function authRequired() {
    if (/\/(login|signin|sign-in|ap\/signin)(\/|$)/i.test(location.pathname)) return true;
    if (query('input[type="password"],input[autocomplete="one-time-code"],iframe[src*="captcha" i],[id*="captcha" i]').some(visible)) return true;
    return /\b(sign in to continue|enter your password|verification code|one.time password|two.step verification|security code|verify you are human|unusual traffic|session has expired|please (sign|log) in)\b/.test(norm(text(document.body)));
  }
  const sessionPhrase = /are you still there|automatically be logged out|session (?:is about to|will) expire|session timeout|stay (?:logged|signed) in|continue (?:your )?session/;
  const safeSession = /^(stay logged in|stay signed in|keep me logged in|keep me signed in|continue session|continue your session|extend session|remain signed in|i['’]m still here|still here|keep working|continue working|yes,? stay (?:signed|logged) in)$/;
  function session() {
    if (authRequired()) return {kind: 'AUTH_REQUIRED'};
    let roots = dialogs().filter(el => sessionPhrase.test(norm(text(el))));
    if (!roots.length) roots = query('div,section').filter(visible).filter(el => text(el).length < 1200 && sessionPhrase.test(norm(text(el))) && actions(el).length);
    roots = roots.filter(el => !roots.some(other => other !== el && el.contains(other)));
    if (!roots.length) return {kind: 'CLEAR'};
    const root = roots[0];
    const button = actions(root).find(el => safeSession.test(label(el)) || (label(el) === 'continue' && root.matches('[role="dialog"],[role="alertdialog"],[aria-modal="true"],dialog')));
    return {kind: 'PROMPT', root, button};
  }
  function confirmation(offer) {
    if (!offer || session().kind !== 'CLEAR') return null;
    const candidates = [...dialogs(), ...query('form,main,[role="main"]').filter(visible)];
    for (const root of candidates) {
      const t = norm(text(root));
      if (!/\b(vto|voluntary time off)\b/.test(t) || !/confirm|accept|submit|review|request/.test(t)) continue;
      const rs = ranges(t);
      const expected = ranges(offer.raw)[0];
      if (rs.length && (rs.length !== 1 || rs[0] !== expected)) continue;
      // Full-page confirmations need an explicit heading; a listing is never a confirmation.
      if (root.matches('main,[role="main"]') && !query('h1,h2,[role="heading"]', root).some(h => /confirm|review/.test(norm(text(h))))) continue;
      const el = actions(root).find(e => /^(confirm|confirm vto|confirm acceptance|confirm accept(?:ance)?|yes,? accept|accept|accept vto|accept voluntary time off|submit|submit request|complete|continue|next)$/.test(label(e)));
      if (el) return el;
    }
    return null;
  }
  function successes() {
    return query('[role="status"],[role="alert"],[aria-live],h1,h2,p,span,div').filter(visible).map(el => ({el, text: norm(text(el))})).filter(x => x.text.length < 600 && /\b(vto|voluntary time off)\b/.test(x.text) && /successfully (?:accepted|claimed)|acceptance confirmed|you have accepted this vto|vto has been accepted/.test(x.text) && !/not |failed|unable|could not/.test(x.text)).filter(x => ![...x.el.children].some(c => /successfully (?:accepted|claimed)|acceptance confirmed|you have accepted this vto|vto has been accepted/.test(norm(text(c)))));
  }
  function freshSuccess(baseline, offer) {
    return successes().find(x => !baseline.has(x.text) && (!ranges(x.text).length || ranges(x.text)[0] === ranges(offer.raw)[0]));
  }
  const events = []; let seq = 0;
  function event(stage, reason, attempt = 0) {
    const e = {seq: ++seq, at: Date.now(), stage, reason, attempt};
    events.push(e); if (events.length > 200) events.shift();
    return e;
  }
  window.VTOReliability = {norm, visible, query, text, label, enabled, actions, ranges, rangeInfo, offers, actionFor, authRequired, session, confirmation, successes, freshSuccess, event, events};
})();
