VTO Watcher 4.5.0

Install:
1. Extract this ZIP to a permanent folder.
2. Open chrome://extensions.
3. Enable Developer mode.
4. Choose Load unpacked and select this extracted folder.
5. Activate with a valid VTO Watcher license.

v4.5.0 uses one unified watcher engine and one clean background service,
persistent runtime, soft VTO refresh, verified live-offer actions,
improved diagnostics, GitHub updates, and a responsive GUI.
