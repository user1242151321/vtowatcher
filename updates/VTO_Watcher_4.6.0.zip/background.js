importScripts("license_config.js");

const LICENSE_STORAGE_DEFAULTS = {
  deviceId: null,
  licenseId: null,
  activationToken: null,
  licenseExpiresAt: null,
  licenseLabel: null,
  licenseValid: false,
  lastLicenseCheck: 0,
  lastLicenseValidAt: 0,
  updateAvailable: false,
  updateRequired: false,
  latestVersion: null,
  minimumVersion: null,
  updateMessage: null,
  updateUrl: null,
  updateObjectKey: null,
  updateDownloadReady: false,
  licenseMaxMajorVersion: 4
};

function serverUrl() {
  return String(LICENSE_CONFIG.SERVER_URL || "").replace(/\/+$/, "");
}

function serverConfigured() {
  const url = serverUrl();
  return /^https:\/\//i.test(url) && !url.includes("YOUR-WORKER-URL");
}


function extensionVersion() {
  return chrome.runtime.getManifest().version;
}

const GITHUB_UPDATE_MANIFEST_URL =
  "https://raw.githubusercontent.com/user1242151321/test/main/updates/latest.json";

function parseSemver(version) {
  return String(version || "0.0.0")
    .replace(/^v/i, "")
    .split(".")
    .slice(0, 3)
    .map(part => Number(String(part).match(/^\d+/)?.[0] || 0));
}

function compareSemver(a, b) {
  const av = parseSemver(a);
  const bv = parseSemver(b);
  while (av.length < 3) av.push(0);
  while (bv.length < 3) bv.push(0);
  for (let i = 0; i < 3; i++) {
    if (av[i] > bv[i]) return 1;
    if (av[i] < bv[i]) return -1;
  }
  return 0;
}

async function mergeGithubUpdateInfo(result = {}) {
  try {
    const response = await fetch(GITHUB_UPDATE_MANIFEST_URL, { cache: "no-store" });
    if (!response.ok) return result;

    const info = await response.json();
    const latestVersion = String(info.latestVersion || "").trim();
    const minimumVersion = String(info.minimumVersion || "0.0.0").trim();
    const currentVersion = extensionVersion();

    if (!latestVersion) return result;

    const updateAvailable = compareSemver(currentVersion, latestVersion) < 0;
    const updateRequired = compareSemver(currentVersion, minimumVersion) < 0;

    return {
      ...result,
      updateAvailable,
      updateRequired,
      latestVersion,
      minimumVersion,
      updateMessage: String(info.message || "").trim() || null,
      updateUrl: String(info.downloadUrl || "").trim() || null,
      updateObjectKey: null,
      updateDownloadReady: Boolean(info.downloadUrl)
    };
  } catch (_) {
    return result;
  }
}

async function updateActionIndicator(result = {}) {
  const required =
    Boolean(result.updateRequired) ||
    result.reason === "update_required";

  const available =
    required ||
    Boolean(result.updateAvailable);

  if (!available) {
    await chrome.action.setBadgeText({ text: "" });
    return;
  }

  await chrome.action.setBadgeText({
    text: required ? "!" : "UP"
  });

  await chrome.action.setBadgeBackgroundColor({
    color: required ? "#ef4444" : "#f59e0b"
  });

  const latest = result.latestVersion || "new";
  const storage = await chrome.storage.local.get({
    lastUpdateNoticeVersion: null
  });

  if (
    result.updateAvailable &&
    storage.lastUpdateNoticeVersion !== latest
  ) {
    await chrome.storage.local.set({
      lastUpdateNoticeVersion: latest
    });

    const notificationState = await chrome.storage.local.get({
      notificationsEnabled: true
    });

    if (notificationState.notificationsEnabled) {
      chrome.notifications.create({
        type: "basic",
        iconUrl: "icons/icon128.png",
        title: required
          ? "VTO Watcher update required"
          : "VTO Watcher update available",
        message:
          result.updateMessage ||
          `Version ${latest} is available. Click the extension icon for update instructions.`
      });
    }
  }
}

async function getDeviceId() {
  const data = await chrome.storage.local.get({ deviceId: null });
  if (data.deviceId) return data.deviceId;

  const deviceId = crypto.randomUUID();
  await chrome.storage.local.set({ deviceId });
  return deviceId;
}

async function clearLocalLicense() {
  await chrome.storage.local.set({
    licenseId: null,
    activationToken: null,
    licenseExpiresAt: null,
    licenseLabel: null,
    licenseValid: false,
    lastLicenseCheck: 0,
    lastLicenseValidAt: 0,
    updateAvailable: false,
    updateRequired: false,
    latestVersion: null,
    minimumVersion: null,
    updateMessage: null,
    updateUrl: null,
    updateObjectKey: null,
    updateDownloadReady: false,
    licenseMaxMajorVersion: 4
  });
}

async function postJson(path, body) {
  const response = await fetch(`${serverUrl()}${path}`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(body)
  });

  let data = {};
  try {
    data = await response.json();
  } catch (_) {}

  if (!response.ok) {
    const error = new Error(data.message || data.error || `HTTP ${response.status}`);
    error.code = data.code || "server_error";
    error.status = response.status;
    error.details = data;
    throw error;
  }

  return data;
}

async function persistVersionInfo(result = {}) {
  await chrome.storage.local.set({
    updateAvailable: Boolean(result.updateAvailable),
    updateRequired: Boolean(result.updateRequired),
    latestVersion: result.latestVersion || null,
    minimumVersion: result.minimumVersion || null,
    updateMessage: result.updateMessage || null,
    updateUrl: result.updateUrl || null,
    updateObjectKey: result.updateObjectKey || null,
    updateDownloadReady: Boolean(result.updateDownloadReady),
    licenseMaxMajorVersion:
      Number.isFinite(Number(result.maxMajorVersion))
        ? Number(result.maxMajorVersion)
        : 4
  });
}

async function activateLicense(key) {
  if (!serverConfigured()) {
    return {
      ok: false,
      valid: false,
      reason: "setup_required",
      message: "License server URL has not been configured yet."
    };
  }

  const cleanKey = String(key || "").trim().toUpperCase();
  if (!cleanKey) {
    return {
      ok: false,
      valid: false,
      reason: "missing_key",
      message: "Enter a license key."
    };
  }

  const deviceId = await getDeviceId();

  try {
    const serverResult = await postJson("/activate", {
      key: cleanKey,
      deviceId,
      extensionVersion: extensionVersion()
    });
    const result = await mergeGithubUpdateInfo(serverResult);

    const now = Date.now();

    await chrome.storage.local.set({
      licenseId: result.licenseId,
      activationToken: result.activationToken,
      licenseExpiresAt: result.expiresAt || null,
      licenseLabel: result.label || null,
      licenseValid: true,
      lastLicenseCheck: now,
      lastLicenseValidAt: now
    });

    await persistVersionInfo(result);
    await updateActionIndicator(result);

    return {
      ok: true,
      valid: true,
      licenseId: result.licenseId,
      expiresAt: result.expiresAt || null,
      label: result.label || null,
      deviceId,
      ...result
    };
  } catch (err) {
    const details = err.details || {};
    await persistVersionInfo(details);
    await updateActionIndicator({
      ...details,
      reason: err.code || "activation_failed"
    });

    return {
      ok: false,
      valid: false,
      reason: err.code || "activation_failed",
      message: err.message || "Activation failed.",
      ...details
    };
  }
}

async function validateRemote(stored) {
  if (!serverConfigured()) {
    return {
      ok: false,
      valid: false,
      reason: "setup_required",
      message: "License server URL has not been configured yet."
    };
  }

  const deviceId = await getDeviceId();

  try {
    const serverResult = await postJson("/validate", {
      licenseId: stored.licenseId,
      activationToken: stored.activationToken,
      deviceId,
      extensionVersion: extensionVersion()
    });
    const result = await mergeGithubUpdateInfo(serverResult);

    const now = Date.now();

    await chrome.storage.local.set({
      licenseValid: true,
      licenseExpiresAt: result.expiresAt || stored.licenseExpiresAt || null,
      licenseLabel: result.label || stored.licenseLabel || null,
      lastLicenseCheck: now,
      lastLicenseValidAt: now
    });

    await persistVersionInfo(result);
    await updateActionIndicator(result);

    return {
      ok: true,
      valid: true,
      expiresAt: result.expiresAt || stored.licenseExpiresAt || null,
      label: result.label || stored.licenseLabel || null,
      deviceId,
      offlineGrace: false,
      ...result
    };
  } catch (err) {
    const details = err.details || {};
    await persistVersionInfo(details);

    // Any definite client rejection locks immediately.
    if (err.status && err.status >= 400 && err.status < 500) {
      await chrome.storage.local.set({
        licenseValid: false,
        lastLicenseCheck: Date.now()
      });

      return {
        ok: false,
        valid: false,
        reason: err.code || "license_rejected",
        message: err.message || "License rejected by server.",
        deviceId,
        ...details
      };
    }

    // Temporary network/server outage:
    // short grace only for a previously validated device.
    const now = Date.now();
    const withinGrace =
      stored.lastLicenseValidAt &&
      (now - Number(stored.lastLicenseValidAt)) <= LICENSE_CONFIG.OFFLINE_GRACE_MS;

    if (stored.licenseValid && withinGrace) {
      return {
        ok: true,
        valid: true,
        offlineGrace: true,
        expiresAt: stored.licenseExpiresAt || null,
        label: stored.licenseLabel || null,
        deviceId,
        message: "Using temporary offline license grace period."
      };
    }

    await chrome.storage.local.set({
      licenseValid: false,
      lastLicenseCheck: now
    });

    return {
      ok: false,
      valid: false,
      reason: "server_unreachable",
      message: "Could not reach the license server.",
      deviceId
    };
  }
}

async function licenseStatus(force = false) {
  const deviceId = await getDeviceId();

  if (!serverConfigured()) {
    return {
      ok: false,
      valid: false,
      reason: "setup_required",
      message: "Set LICENSE_CONFIG.SERVER_URL in license_config.js.",
      deviceId
    };
  }

  const stored = await chrome.storage.local.get(LICENSE_STORAGE_DEFAULTS);

  if (!stored.licenseId || !stored.activationToken) {
    return {
      ok: true,
      valid: false,
      reason: "not_activated",
      message: "This device has not been activated.",
      deviceId
    };
  }

  if (stored.licenseExpiresAt) {
    const expiry = new Date(stored.licenseExpiresAt).getTime();
    if (Number.isFinite(expiry) && Date.now() > expiry) {
      await chrome.storage.local.set({ licenseValid: false });
      return {
        ok: true,
        valid: false,
        reason: "expired",
        message: "This license has expired.",
        expiresAt: stored.licenseExpiresAt,
        deviceId
      };
    }
  }

  const freshEnough =
    stored.licenseValid &&
    stored.lastLicenseCheck &&
    (Date.now() - Number(stored.lastLicenseCheck)) < LICENSE_CONFIG.VALIDATE_EVERY_MS;

  if (!force && freshEnough) {
    await updateActionIndicator({
      updateAvailable: Boolean(stored.updateAvailable),
      updateRequired: Boolean(stored.updateRequired),
      latestVersion: stored.latestVersion || null,
      updateMessage: stored.updateMessage || null,
      updateUrl: stored.updateUrl || null,
      updateObjectKey: stored.updateObjectKey || null,
      updateDownloadReady: Boolean(stored.updateDownloadReady)
    });

    return {
      ok: true,
      valid: true,
      expiresAt: stored.licenseExpiresAt || null,
      label: stored.licenseLabel || null,
      deviceId,
      offlineGrace: false,
      updateAvailable: Boolean(stored.updateAvailable),
      updateRequired: Boolean(stored.updateRequired),
      latestVersion: stored.latestVersion || null,
      minimumVersion: stored.minimumVersion || null,
      updateMessage: stored.updateMessage || null,
      updateUrl: stored.updateUrl || null,
      updateObjectKey: stored.updateObjectKey || null,
      updateDownloadReady: Boolean(stored.updateDownloadReady),
      maxMajorVersion: stored.licenseMaxMajorVersion || 4
    };
  }

  return validateRemote(stored);
}


async function requestProtectedUpdateDownload() {
  if (!serverConfigured()) {
    return {
      ok: false,
      message: "License server is not configured."
    };
  }

  const stored = await chrome.storage.local.get(LICENSE_STORAGE_DEFAULTS);
  const deviceId = await getDeviceId();

  if (!stored.licenseId || !stored.activationToken) {
    return {
      ok: false,
      message: "Activate this device before downloading updates."
    };
  }

  try {
    const result = await postJson("/update-ticket", {
      licenseId: stored.licenseId,
      activationToken: stored.activationToken,
      deviceId,
      extensionVersion: extensionVersion()
    });

    if (!result.downloadUrl) {
      return {
        ok: false,
        message: "The server did not return an update download."
      };
    }

    await chrome.tabs.create({ url: result.downloadUrl });

    return {
      ok: true,
      latestVersion: result.latestVersion || null,
      filename: result.filename || null
    };
  } catch (err) {
    return {
      ok: false,
      message: err.message || "Could not prepare the protected update download.",
      reason: err.code || "update_download_failed"
    };
  }
}

async function deactivateLicense() {
  const stored = await chrome.storage.local.get(LICENSE_STORAGE_DEFAULTS);
  const deviceId = await getDeviceId();

  if (serverConfigured() && stored.licenseId && stored.activationToken) {
    try {
      await postJson("/deactivate", {
        licenseId: stored.licenseId,
        activationToken: stored.activationToken,
        deviceId
      });
    } catch (_) {}
  }

  await clearLocalLicense();
  return { ok: true, valid: false };
}

chrome.runtime.onInstalled.addListener(async () => {
  await getDeviceId();

  const defaults = {
    armed: false,
    paused: false,
    refreshSeconds: 5,
    autoConfirm: false,
    testMode: false,
    soundEnabled: true,
    notificationsEnabled: true,
    tabFlashEnabled: true,
    minHours: 0,
    startAfter: "any",
    preferLongest: true,
    maxAcceptsPerArm: 1,
    acceptedThisArm: 0
  };

  const current = await chrome.storage.local.get(defaults);
  await chrome.storage.local.set({ ...defaults, ...current });
});

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (!message || typeof message !== "object") return;

  if (message.type === "activateLicense") {
    activateLicense(message.key).then(sendResponse);
    return true;
  }

  if (message.type === "licenseStatus") {
    licenseStatus(Boolean(message.force)).then(sendResponse);
    return true;
  }

  if (message.type === "deactivateLicense") {
    deactivateLicense().then(sendResponse);
    return true;
  }

  if (message.type === "downloadProtectedUpdate") {
    requestProtectedUpdateDownload().then(sendResponse);
    return true;
  }

  if (message.type === "notify") {
    (async () => {
      const license = await licenseStatus(false);
      if (!license.valid) {
        sendResponse({ ok: false, reason: "license_invalid" });
        return;
      }

      const state = await chrome.storage.local.get({
        notificationsEnabled: true
      });

      if (!state.notificationsEnabled) {
        sendResponse({ ok: false, reason: "notifications_disabled" });
        return;
      }

      chrome.notifications.create({
        type: "basic",
        iconUrl: "icons/icon128.png",
        title: message.title || "VTO Watcher",
        message: message.message || ""
      }, () => sendResponse({ ok: !chrome.runtime.lastError }));
    })();

    return true;
  }

  if (message.type === "getState") {
    chrome.storage.local.get(null).then(sendResponse);
    return true;
  }

  if (message.type === "setState") {
    chrome.storage.local.set(message.patch || {}).then(() => sendResponse({ ok: true }));
    return true;
  }
});