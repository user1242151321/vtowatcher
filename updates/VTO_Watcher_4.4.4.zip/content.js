(() => {
  "use strict";

  if (window.__VTO_WATCHER_V4_LOADED__) return;
  window.__VTO_WATCHER_V4_LOADED__ = true;

  const DEFAULTS = {
    armed: false,
    paused: false,
    refreshSeconds: 5,
    autoConfirm: false,
    testMode: false,
    soundEnabled: true,
    notificationsEnabled: true,
    tabFlashEnabled: true,
    minHours: 0,
    startAfter: "any",
    preferLongest: true,
    maxAcceptsPerArm: 1,
    acceptedThisArm: 0,
    panelX: null,
    panelY: null,
    panelMinimized: false
  };

  const FRESH_KEYS = {
    pending: "vto4.fresh.pending",
    startedAt: "vto4.fresh.startedAt",
    weakBaseline: "vto4.fresh.weakBaseline"
  };

  const STRONG_SUCCESS_PHRASES = [
    "successfully accepted",
    "successfully claimed",
    "acceptance confirmed",
    "you have accepted this vto",
    "vto has been accepted"
  ];

  const WEAK_SUCCESS_PHRASES = [
    "vto accepted",
    "you accepted"
  ];

  let state = { ...DEFAULTS };
  let busy = false;
  let refreshTimer = null;
  let countdownTimer = null;
  let scanTimer = null;
  let scanDebounce = null;
  let secondsRemaining = 5;
  let lastActionAt = 0;
  let lastFoundNoticeAt = 0;
  let lastRefreshAt = null;
  let startedAt = Date.now();
  let stats = {
    checks: 0,
    filledSeen: 0,
    opportunitiesSeen: 0,
    errors: 0,
    refreshes: 0
  };
  let activity = [];
  let currentOffer = null;
  let originalTitle = document.title;
  let titleFlashTimer = null;
  let titleFlashFlip = false;

  let panel, statusEl, countdownEl, lastCheckEl, runtimeEl, statsEl, offerEl,
      armBtn, pauseBtn, autoBtn, testBtn, soundBtn, notifyBtn, flashBtn,
      longestBtn, refreshSelect, minHoursInput, startAfterSelect, activityEl;

  const sleep = ms => new Promise(resolve => setTimeout(resolve, ms));

  function normalize(text) {
    return (text || "").replace(/\s+/g, " ").trim().toLowerCase();
  }

  function bodyText() {
    return normalize(document.body?.innerText || "");
  }

  function elementText(el) {
    if (!el) return "";
    return normalize(
      el.innerText ||
      el.textContent ||
      el.value ||
      el.getAttribute?.("aria-label") ||
      el.getAttribute?.("title") ||
      ""
    );
  }

  function isVisible(el) {
    if (!el || !(el instanceof Element)) return false;
    const s = getComputedStyle(el);
    const r = el.getBoundingClientRect();
    return s.display !== "none" &&
      s.visibility !== "hidden" &&
      Number(s.opacity || 1) > 0 &&
      r.width > 0 &&
      r.height > 0;
  }

  function clickableElements(root = document) {
    return [...root.querySelectorAll(
      'button,a,[role="button"],input[type="button"],input[type="submit"]'
    )].filter(isVisible);
  }

  async function storageGet() {
    return await chrome.storage.local.get(DEFAULTS);
  }

  async function storageSet(patch) {
    state = { ...state, ...patch };
    await chrome.storage.local.set(patch);
  }

  function currentTime() {
    return new Date().toLocaleTimeString([], {
      hour: "2-digit", minute: "2-digit", second: "2-digit"
    });
  }

  function durationText(ms) {
    const total = Math.max(0, Math.floor(ms / 1000));
    const h = String(Math.floor(total / 3600)).padStart(2, "0");
    const m = String(Math.floor((total % 3600) / 60)).padStart(2, "0");
    const s = String(total % 60).padStart(2, "0");
    return `${h}:${m}:${s}`;
  }

  function addLog(message) {
    activity.unshift({ time: currentTime(), message });
    if (activity.length > 30) activity.length = 30;
    updateActivity();
    console.log("[VTO Watcher V4]", message);
  }

  function isVtoPage() {
    const t = bodyText();
    return t.includes("voluntary time off (vto)") &&
      t.includes("accepting voluntary time off");
  }

  function loginDetected() {
    const t = bodyText();
    return location.pathname.includes("login") ||
      (t.includes("password") && (t.includes("log in") || t.includes("sign in")));
  }

  function pageErrorDetected() {
    const t = bodyText();
    return [
      "something went wrong",
      "try again later",
      "unexpected error",
      "page unavailable"
    ].some(x => t.includes(x));
  }

  function isUnavailableText(text) {
    const t = normalize(text);
    return [
      "vto filled",
      "vto full",
      "opportunity filled",
      "no longer available",
      "unavailable",
      "expired",
      "already accepted",
      "previously accepted",
      "you accepted",
      "vto accepted"
    ].some(x => t.includes(x));
  }

  function hasTimeRange(text) {
    return /\b\d{1,2}:\d{2}\s*(am|pm)\s*-\s*\d{1,2}:\d{2}\s*(am|pm)\b/i
      .test(text || "");
  }

  function parseClockMinutes(raw) {
    const m = String(raw || "").match(/(\d{1,2}):(\d{2})\s*(am|pm)/i);
    if (!m) return null;
    let h = Number(m[1]);
    const min = Number(m[2]);
    const ap = m[3].toLowerCase();
    if (h === 12) h = 0;
    if (ap === "pm") h += 12;
    return h * 60 + min;
  }

  function extractTimeRange(text) {
    const m = String(text || "").match(
      /(\d{1,2}:\d{2}\s*(?:am|pm))\s*-\s*(\d{1,2}:\d{2}\s*(?:am|pm))/i
    );
    if (!m) return null;

    const start = parseClockMinutes(m[1]);
    let end = parseClockMinutes(m[2]);
    if (start == null || end == null) return null;
    if (end <= start) end += 24 * 60;

    return {
      startText: m[1],
      endText: m[2],
      startMinutes: start,
      endMinutes: end,
      hours: (end - start) / 60
    };
  }

  function parseDurationFromText(text) {
    const t = String(text || "");
    let hours = 0;

    const h = t.match(/(\d+(?:\.\d+)?)\s*hrs?/i);
    const m = t.match(/(\d+)\s*mins?/i);

    if (h) hours += Number(h[1]);
    if (m) hours += Number(m[1]) / 60;

    if (hours > 0) return hours;

    const range = extractTimeRange(t);
    return range?.hours ?? null;
  }

  function findDateTextNearCard(card) {
    let current = card;
    for (let i = 0; i < 6 && current && current !== document.body; i++) {
      const raw = current.innerText || "";
      const match = raw.match(
        /\b(?:Mon|Tue|Wed|Thu|Fri|Sat|Sun)(?:day)?,?\s+(?:Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Sept|Oct|Nov|Dec)[a-z]*\s+\d{1,2}(?:,\s*\d{4})?/i
      );
      if (match) return match[0];
      current = current.parentElement;
    }
    return null;
  }

  function parseOfferDate(dateText) {
    if (!dateText) return null;
    const now = new Date();
    let text = dateText;
    if (!/\b\d{4}\b/.test(text)) text += `, ${now.getFullYear()}`;
    const d = new Date(text);
    if (Number.isNaN(d.getTime())) return null;

    // Handle year rollover around New Year.
    if (d.getTime() < now.getTime() - 200 * 24 * 3600 * 1000) {
      d.setFullYear(d.getFullYear() + 1);
    }
    return d;
  }

  function isPastDate(date) {
    if (!date) return false;
    const a = new Date(date);
    const b = new Date();
    a.setHours(0,0,0,0);
    b.setHours(0,0,0,0);
    return a < b;
  }

  function inferLocation(text) {
    const lines = String(text || "")
      .split(/\n+/)
      .map(x => x.trim())
      .filter(Boolean);

    const skip = /vto|voluntary|filled|accepted|\d{1,2}:\d{2}|hrs?|mins?|confirm|accept|claim/i;
    return lines.find(line => line.length < 80 && !skip.test(line)) || "";
  }

  function offerStateText(text) {
    const t = normalize(text);

    return (
      t.includes("vto filled") ||
      t.includes("vto full") ||
      t.includes("opportunity filled") ||
      t.includes("no longer available") ||
      t.includes("unavailable") ||
      t.includes("expired") ||
      t.includes("already accepted") ||
      t.includes("previously accepted") ||
      t.includes("you accepted") ||
      t.includes("vto accepted") ||
      t.includes("accept vto") ||
      t.includes("claim vto") ||
      t.includes("take vto")
    );
  }

  function smallestTimeSeeds() {
    const candidates = [...document.querySelectorAll("div,section,article,li")]
      .filter(isVisible)
      .filter(el => {
        const raw = el.innerText || "";
        return hasTimeRange(raw) && normalize(raw).length < 2200;
      });

    return candidates.filter(seed => {
      return ![...seed.children].some(child =>
        hasTimeRange(child.innerText || "")
      );
    });
  }

  function expandSeedToOfferCard(seed) {
    let current = seed;
    let best = seed;

    for (let i = 0; i < 8 && current && current !== document.body; i++) {
      const raw = current.innerText || "";
      const t = normalize(raw);

      if (!hasTimeRange(raw)) {
        current = current.parentElement;
        continue;
      }

      const timeMatches = raw.match(
        /\b\d{1,2}:\d{2}\s*(?:am|pm)\s*-\s*\d{1,2}:\d{2}\s*(?:am|pm)\b/gi
      ) || [];

      const uniqueTimes = [...new Set(timeMatches.map(x => normalize(x)))];

      if (uniqueTimes.length > 1) {
        break;
      }

      if (t.length < 2200) {
        best = current;
      }

      // V4.2.1 fix:
      // walk up to the FIRST ancestor that includes the actual VTO state
      // so "VTO Filled" / "VTO Accepted" is not missed.
      if (offerStateText(raw)) {
        return current;
      }

      const action = clickableElements(current).some(el => {
        const a = elementText(el);
        return (
          a === "accept" ||
          a === "claim" ||
          a === "take vto" ||
          a.includes("accept vto") ||
          a.includes("claim vto") ||
          a.includes("view") ||
          a.includes("details") ||
          a.includes("select") ||
          a.includes("continue")
        );
      });

      if (action) {
        return current;
      }

      current = current.parentElement;
    }

    return best;
  }

  function collectOfferCards() {
    if (!isVtoPage()) return [];

    const containers = smallestTimeSeeds()
      .map(expandSeedToOfferCard)
      .filter(Boolean);

    const uniqueCards = [...new Set(containers)];

    return uniqueCards.map(card => {
      const raw = card.innerText || "";
      const range = extractTimeRange(raw);
      const duration = parseDurationFromText(raw);
      const dateText = findDateTextNearCard(card);
      const date = parseOfferDate(dateText);

      const unavailable =
        isUnavailableText(raw) ||
        isPastDate(date);

      return {
        card,
        raw,
        normalized: normalize(raw),
        startText: range?.startText || "",
        endText: range?.endText || "",
        startMinutes: range?.startMinutes ?? null,
        endMinutes: range?.endMinutes ?? null,
        hours: duration ?? range?.hours ?? 0,
        dateText: dateText || "",
        date,
        location: inferLocation(raw),
        unavailable
      };
    });
  }

  function filterOffer(offer) {
    if (offer.unavailable) return false;
    if (Number(state.minHours) > 0 && offer.hours < Number(state.minHours)) {
      return false;
    }

    if (state.startAfter !== "any" && offer.startMinutes != null) {
      const threshold = Number(state.startAfter);
      if (offer.startMinutes < threshold) return false;
    }

    return true;
  }

  function eligibleOffers() {
    const offers = collectOfferCards().filter(filterOffer);

    if (state.preferLongest) {
      offers.sort((a, b) => (b.hours || 0) - (a.hours || 0));
    }

    return offers;
  }

  function filledOldOffers() {
    return collectOfferCards().filter(o => o.unavailable);
  }

  function findClosestOfferCard(element) {
    let current = element;
    let best = null;

    for (let i = 0; i < 9 && current && current !== document.body; i++) {
      const raw = current.innerText || "";
      if (hasTimeRange(raw) && normalize(raw).length < 2500) best = current;
      current = current.parentElement;
    }

    return best;
  }

  function findConfirmButton() {
    if (!isVtoPage()) return null;

    return clickableElements().find(el => {
      const t = elementText(el);
      const match =
        t === "confirm" ||
        t.includes("confirm accept") ||
        t.includes("confirm vto") ||
        t.includes("confirm acceptance");

      if (!match) return false;

      const card = findClosestOfferCard(el);
      return !(card && isUnavailableText(elementText(card)));
    }) || null;
  }

  function findAcceptButton() {
    if (!isVtoPage()) return null;

    return clickableElements().find(el => {
      const t = elementText(el);
      const match =
        t === "accept" ||
        t === "claim" ||
        t === "take vto" ||
        t.includes("accept vto") ||
        t.includes("claim vto");

      if (!match) return false;

      const card = findClosestOfferCard(el);
      if (card && isUnavailableText(elementText(card))) return false;

      // If button belongs to a card, make sure that card passes current filters.
      if (card) {
        const offer = collectOfferCards().find(o => o.card === card);
        if (offer && !filterOffer(offer)) return false;
      }

      return true;
    }) || null;
  }

  function actionFromOffer(offer) {
    if (!offer) return null;

    for (const el of clickableElements(offer.card)) {
      const t = elementText(el);
      if (
        t.includes("view") ||
        t.includes("details") ||
        t.includes("select") ||
        t.includes("continue") ||
        t.includes("accept") ||
        t.includes("claim") ||
        t === "vto"
      ) {
        return el;
      }
    }

    const s = getComputedStyle(offer.card);
    if (
      offer.card.getAttribute("role") === "button" ||
      offer.card.hasAttribute("onclick") ||
      offer.card.tabIndex >= 0 ||
      s.cursor === "pointer"
    ) {
      return offer.card;
    }

    return null;
  }

  function countOccurrences(text, phrase) {
    if (!text || !phrase) return 0;
    return text.split(phrase).length - 1;
  }

  function countWeakSignals(text = bodyText()) {
    return WEAK_SUCCESS_PHRASES.reduce(
      (sum, phrase) => sum + countOccurrences(text, phrase),
      0
    );
  }

  function beginFreshAcceptanceWatch() {
    sessionStorage.setItem(FRESH_KEYS.pending, "true");
    sessionStorage.setItem(FRESH_KEYS.startedAt, String(Date.now()));
    sessionStorage.setItem(FRESH_KEYS.weakBaseline, String(countWeakSignals()));
  }

  function clearFreshAcceptanceWatch() {
    Object.values(FRESH_KEYS).forEach(k => sessionStorage.removeItem(k));
  }

  function successDetected() {
    if (sessionStorage.getItem(FRESH_KEYS.pending) !== "true") return false;

    const started = Number(sessionStorage.getItem(FRESH_KEYS.startedAt) || 0);
    if (!started || Date.now() - started > 45000) {
      clearFreshAcceptanceWatch();
      return false;
    }

    const t = bodyText();

    if (STRONG_SUCCESS_PHRASES.some(p => t.includes(p))) return true;

    const baseline = Number(sessionStorage.getItem(FRESH_KEYS.weakBaseline) || 0);
    return countWeakSignals(t) > baseline;
  }

  function beep(freq = 760, duration = 0.12) {
    if (!state.soundEnabled) return;
    try {
      const AC = window.AudioContext || window.webkitAudioContext;
      if (!AC) return;
      const ctx = new AC();
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.frequency.value = freq;
      gain.gain.value = 0.05;
      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start();
      setTimeout(() => {
        osc.stop();
        ctx.close();
      }, duration * 1000);
    } catch (_) {}
  }

  function foundSound() {
    beep(740, .10);
    setTimeout(() => beep(920, .10), 130);
    setTimeout(() => beep(1100, .16), 260);
  }

  function notify(title, message) {
    if (!state.notificationsEnabled) return;
    chrome.runtime.sendMessage({ type: "notify", title, message }).catch(() => {});
  }

  function startTitleFlash(text = "🔥 VTO FOUND 🔥") {
    if (!state.tabFlashEnabled || titleFlashTimer) return;
    originalTitle = document.title;
    titleFlashTimer = setInterval(() => {
      titleFlashFlip = !titleFlashFlip;
      document.title = titleFlashFlip ? text : originalTitle;
    }, 700);

    setTimeout(stopTitleFlash, 12000);
  }

  function stopTitleFlash() {
    if (titleFlashTimer) clearInterval(titleFlashTimer);
    titleFlashTimer = null;
    document.title = originalTitle;
  }

  function notifyFoundOnce(title, message) {
    const now = Date.now();
    if (now - lastFoundNoticeAt < 5000) return;
    lastFoundNoticeAt = now;
    foundSound();
    notify(title, message);
    startTitleFlash();
  }

  async function actOnElement(el, description) {
    if (!el || !isVisible(el) || busy) return false;

    const now = Date.now();
    if (now - lastActionAt < 1500) return false;
    lastActionAt = now;

    if (state.testMode) {
      setStatus(`TEST MODE — would ${description}`, "found");
      addLog(`TEST: would ${description}`);
      return false;
    }

    busy = true;
    setStatus(`${description}...`, "found");
    addLog(description);

    try {
      el.scrollIntoView({ behavior: "smooth", block: "center" });
      await sleep(300);

      if (normalize(description).includes("confirm vto")) {
        beginFreshAcceptanceWatch();
      }

      el.click();
      await sleep(1100);
      return true;
    } catch (err) {
      stats.errors++;
      setStatus("Click error", "error");
      addLog(`Click error: ${err?.message || err}`);
      return false;
    } finally {
      busy = false;
      updateStats();
    }
  }

  document.addEventListener("click", event => {
    if (!isVtoPage()) return;
    const target = event.target instanceof Element
      ? event.target.closest('button,a,[role="button"],input[type="button"],input[type="submit"]')
      : null;

    if (!target) return;
    const t = elementText(target);
    const isConfirm =
      t === "confirm" ||
      t.includes("confirm vto") ||
      t.includes("confirm accept") ||
      t.includes("confirm acceptance");

    if (isConfirm) {
      beginFreshAcceptanceWatch();
      addLog("Manual VTO confirmation detected");
    }
  }, true);

  function describeOffer(offer) {
    if (!offer) return "No eligible VTO currently detected.";
    const parts = [];
    if (offer.dateText) parts.push(offer.dateText);
    if (offer.startText && offer.endText) parts.push(`${offer.startText} – ${offer.endText}`);
    if (offer.hours) parts.push(`${offer.hours.toFixed(2).replace(/\.00$/, "")} hr`);
    if (offer.location) parts.push(offer.location);
    return parts.join(" • ");
  }

  async function scan() {
    if (!state.armed || state.paused || busy) return;

    stats.checks++;
    updateStats();
    if (lastCheckEl) lastCheckEl.textContent = currentTime();

    if (loginDetected()) {
      setStatus("Login required", "error");
      addLog("Login required");
      stopRefresh();
      notify("VTO Watcher", "Amazon A to Z needs you to log in again.");
      return;
    }

    if (pageErrorDetected()) {
      stats.errors++;
      setStatus("A to Z page error", "error");
      addLog("Page error detected");
      updateStats();
      return;
    }

    if (!isVtoPage()) {
      setStatus("Open Schedule → VTO", "warning");
      currentOffer = null;
      updateOffer();
      return;
    }

    if (state.acceptedThisArm >= state.maxAcceptsPerArm) {
      await disarm("Maximum VTO accepted");
      return;
    }

    if (successDetected()) {
      const nextAccepted = state.acceptedThisArm + 1;
      await storageSet({ acceptedThisArm: nextAccepted });
      clearFreshAcceptanceWatch();

      setStatus("VTO ACCEPTED!", "success");
      addLog("VTO ACCEPTED");
      notify("VTO ACCEPTED", "Your new VTO appears to have been accepted.");
      beep(1000, .12);
      setTimeout(() => beep(1250, .18), 160);
      setTimeout(() => disarm("VTO accepted"), 800);
      return;
    }

    const confirm = findConfirmButton();
    if (confirm) {
      if (state.autoConfirm) {
        await actOnElement(confirm, "Confirm VTO");
      } else {
        setStatus("Confirmation ready — Auto Confirm OFF", "found");
        notifyFoundOnce("VTO READY", "A new VTO is ready for final confirmation.");
      }
      return;
    }

    const offers = eligibleOffers();
    currentOffer = offers[0] || null;
    updateOffer();

    const accept = findAcceptButton();
    if (accept) {
      stats.opportunitiesSeen++;
      updateStats();
      notifyFoundOnce("VTO FOUND", describeOffer(currentOffer));
      await actOnElement(accept, "Accept VTO");
      return;
    }

    if (currentOffer) {
      const action = actionFromOffer(currentOffer);
      if (action) {
        stats.opportunitiesSeen++;
        updateStats();
        notifyFoundOnce("VTO FOUND", describeOffer(currentOffer));
        await actOnElement(action, "Open available VTO");
        return;
      }

      setStatus("Eligible VTO detected", "found");
      notifyFoundOnce("VTO FOUND", describeOffer(currentOffer));
      return;
    }

    const oldCount = filledOldOffers().length;
    if (oldCount > 0) {
      stats.filledSeen++;
      setStatus(`Watching — ${oldCount} filled/old`, "armed");
    } else {
      setStatus("Watching for VTO", "armed");
    }
    updateStats();
  }

  function stopRefresh() {
    if (refreshTimer) clearTimeout(refreshTimer);
    if (countdownTimer) clearInterval(countdownTimer);
    refreshTimer = null;
    countdownTimer = null;
  }

  function startRefresh() {
    stopRefresh();

    if (!state.armed || state.paused) {
      secondsRemaining = state.refreshSeconds;
      updateCountdown();
      return;
    }

    secondsRemaining = Math.max(5, Number(state.refreshSeconds) || 5);
    updateCountdown();

    countdownTimer = setInterval(() => {
      if (!state.armed || state.paused) return;
      secondsRemaining = Math.max(0, secondsRemaining - 1);
      updateCountdown();
    }, 1000);

    refreshTimer = setTimeout(() => {
      if (!state.armed || state.paused) return;
      if (busy || !isVtoPage()) {
        startRefresh();
        return;
      }

      stats.refreshes++;
      lastRefreshAt = Date.now();
      addLog("Refreshing VTO page");
      location.reload();
    }, secondsRemaining * 1000);
  }

  async function arm() {
    const license = await window.VTOLicense.requireValid(true);
    if (!license?.valid) {
      addLog("Arm blocked — license inactive");
      return;
    }

    clearFreshAcceptanceWatch();
    stats = {
      checks: 0,
      filledSeen: 0,
      opportunitiesSeen: 0,
      errors: 0,
      refreshes: 0
    };
    activity = [];
    startedAt = Date.now();
    await storageSet({
      armed: true,
      paused: false,
      acceptedThisArm: 0
    });
    setStatus("ARMED — watching", "armed");
    addLog("Watcher armed");
    beep(650, .08);
    updatePanel();
    startRefresh();
    scan();
  }

  async function disarm(reason = "Disarmed") {
    stopTitleFlash();
    clearFreshAcceptanceWatch();
    await storageSet({
      armed: false,
      paused: false
    });
    stopRefresh();
    setStatus(reason, "off");
    addLog(reason);
    updatePanel();
  }

  async function togglePause() {
    if (!state.armed) return;
    const paused = !state.paused;
    await storageSet({ paused });
    if (paused) {
      stopRefresh();
      setStatus("PAUSED", "warning");
      addLog("Watcher paused");
    } else {
      setStatus("ARMED — watching", "armed");
      addLog("Watcher resumed");
      startRefresh();
      scan();
    }
    updatePanel();
  }

  function setStatus(message, type = "off") {
    if (!statusEl) return;

    const colors = {
      off: "#374151",
      armed: "#065f46",
      success: "#047857",
      found: "#b45309",
      warning: "#92400e",
      error: "#991b1b"
    };

    statusEl.textContent = message;
    statusEl.style.background = colors[type] || colors.off;
    if (panel) panel.style.borderColor = colors[type] || "#4b5563";
  }

  function updateCountdown() {
    if (!countdownEl) return;
    if (!state.armed) countdownEl.textContent = "--";
    else if (state.paused) countdownEl.textContent = "PAUSED";
    else countdownEl.textContent = `${secondsRemaining}s`;
  }

  function updateStats() {
    if (!statsEl) return;
    statsEl.textContent =
      `Checks ${stats.checks} • Refreshes ${stats.refreshes} • Found ${stats.opportunitiesSeen} • Old ${stats.filledSeen} • Accepted ${state.acceptedThisArm}/1`;
  }

  function updateOffer() {
    if (!offerEl) return;
    offerEl.textContent = describeOffer(currentOffer);
  }

  function updateActivity() {
    if (!activityEl) return;

    if (!activity.length) {
      activityEl.innerHTML = '<div style="opacity:.55">No activity yet</div>';
      return;
    }

    activityEl.innerHTML = activity.slice(0, 12).map(x =>
      `<div class="vto-log-entry">${escapeHtml(x.time)} — ${escapeHtml(x.message)}</div>`
    ).join("");
  }

  function escapeHtml(s) {
    return String(s)
      .replaceAll("&", "&amp;")
      .replaceAll("<", "&lt;")
      .replaceAll(">", "&gt;")
      .replaceAll('"', "&quot;")
      .replaceAll("'", "&#039;");
  }

  function toggleButton(btn, enabled, label) {
    if (!btn) return;
    btn.classList.toggle("on", !!enabled);
    btn.textContent = `${label}: ${enabled ? "ON" : "OFF"}`;
  }

  function updatePanel() {
    if (!panel) return;

    armBtn.textContent = state.armed ? "⏹ DISARM VTO" : "⚡ ARM VTO";
    armBtn.classList.toggle("disarm", state.armed);

    pauseBtn.textContent = state.paused ? "▶ RESUME" : "⏸ PAUSE";
    pauseBtn.disabled = !state.armed;

    toggleButton(autoBtn, state.autoConfirm, "Auto Confirm");
    toggleButton(testBtn, state.testMode, "Test Mode");
    toggleButton(soundBtn, state.soundEnabled, "Sound");
    toggleButton(notifyBtn, state.notificationsEnabled, "Notify");
    toggleButton(flashBtn, state.tabFlashEnabled, "Tab Flash");
    toggleButton(longestBtn, state.preferLongest, "Prefer Longest");

    refreshSelect.value = String(Math.max(5, Number(state.refreshSeconds) || 5));
    minHoursInput.value = String(state.minHours ?? 0);
    startAfterSelect.value = String(state.startAfter ?? "any");

    panel.classList.toggle("vto-minimized", !!state.panelMinimized);
    updateCountdown();
    updateStats();
    updateOffer();
    updateActivity();
  }

  async function copyLog() {
    const text = activity
      .slice()
      .reverse()
      .map(x => `${x.time} — ${x.message}`)
      .join("\n");

    try {
      await navigator.clipboard.writeText(text);
      addLog("Activity log copied");
    } catch {
      addLog("Could not copy log");
    }
  }

  function buildPanel() {
    if (document.getElementById("vto-v4-panel")) return;

    panel = document.createElement("div");
    panel.id = "vto-v4-panel";

    panel.innerHTML = `
      <div class="vto-v4-header" id="vto-v4-drag">
        <div class="vto-v4-title">⚡ VTO WATCHER <span class="vto-v4-badge">V4.2.4 EXT</span></div>
        <div class="vto-v4-header-actions">
          <button class="vto-icon-btn" id="vto-v4-min" title="Minimize">—</button>
        </div>
      </div>

      <div class="vto-v4-body">
        <div class="vto-status" id="vto-v4-status">Loading...</div>

        <div class="vto-grid-2">
          <div class="vto-card">Next refresh<strong id="vto-v4-countdown">--</strong></div>
          <div class="vto-card">Last check<strong id="vto-v4-lastcheck">--</strong></div>
          <div class="vto-card">Runtime<strong id="vto-v4-runtime">00:00:00</strong></div>
          <div class="vto-card">Refresh interval<strong id="vto-v4-interval-label">5s</strong></div>
        </div>

        <div class="vto-section">
          <div class="vto-section-title">Best eligible VTO</div>
          <div class="vto-offer-box" id="vto-v4-offer">No eligible VTO currently detected.</div>
        </div>

        <div class="vto-section">
          <div class="vto-section-title">Filters</div>
          <div class="vto-grid-2">
            <div>
              <label>Minimum hours</label>
              <input class="vto-number" id="vto-v4-min-hours" type="number" min="0" max="24" step="0.25">
            </div>
            <div>
              <label>Start after</label>
              <select class="vto-select" id="vto-v4-start-after">
                <option value="any">Any time</option>
                <option value="720">12:00 PM</option>
                <option value="840">2:00 PM</option>
                <option value="960">4:00 PM</option>
                <option value="1080">6:00 PM</option>
                <option value="1200">8:00 PM</option>
              </select>
            </div>
          </div>
          <button class="vto-toggle" id="vto-v4-longest" style="width:100%;margin-top:6px">Prefer Longest</button>
        </div>

        <div class="vto-section">
          <div class="vto-section-title">Watcher</div>
          <div class="vto-grid-2">
            <select class="vto-select" id="vto-v4-refresh">
              <option value="5">5 seconds</option>
              <option value="10">10 seconds</option>
              <option value="15">15 seconds</option>
              <option value="20">20 seconds</option>
              <option value="30">30 seconds</option>
              <option value="60">60 seconds</option>
            </select>
            <button class="vto-secondary" id="vto-v4-scan">🔎 Scan Now</button>
          </div>

          <div class="vto-grid-2" style="margin-top:6px">
            <button class="vto-toggle" id="vto-v4-auto">Auto Confirm</button>
            <button class="vto-toggle" id="vto-v4-test">Test Mode</button>
            <button class="vto-toggle" id="vto-v4-sound">Sound</button>
            <button class="vto-toggle" id="vto-v4-notify">Notify</button>
            <button class="vto-toggle" id="vto-v4-flash">Tab Flash</button>
            <button class="vto-secondary" id="vto-v4-pause">⏸ PAUSE</button>
          </div>

          <button class="vto-main" id="vto-v4-arm">⚡ ARM VTO</button>
        </div>

        <div class="vto-section">
          <div class="vto-section-title" id="vto-v4-stats">Stats</div>
          <div class="vto-grid-2">
            <button class="vto-secondary" id="vto-v4-copy">Copy Log</button>
            <button class="vto-secondary" id="vto-v4-clear">Clear Log</button>
          </div>
          <div class="vto-log" id="vto-v4-activity" style="margin-top:6px"></div>
        </div>

        <div class="vto-footer">VTO only • ignores old/accepted offers • max 1 new VTO per arm</div>
      </div>
    `;

    document.documentElement.appendChild(panel);

    statusEl = panel.querySelector("#vto-v4-status");
    countdownEl = panel.querySelector("#vto-v4-countdown");
    lastCheckEl = panel.querySelector("#vto-v4-lastcheck");
    runtimeEl = panel.querySelector("#vto-v4-runtime");
    statsEl = panel.querySelector("#vto-v4-stats");
    offerEl = panel.querySelector("#vto-v4-offer");
    armBtn = panel.querySelector("#vto-v4-arm");
    pauseBtn = panel.querySelector("#vto-v4-pause");
    autoBtn = panel.querySelector("#vto-v4-auto");
    testBtn = panel.querySelector("#vto-v4-test");
    soundBtn = panel.querySelector("#vto-v4-sound");
    notifyBtn = panel.querySelector("#vto-v4-notify");
    flashBtn = panel.querySelector("#vto-v4-flash");
    longestBtn = panel.querySelector("#vto-v4-longest");
    refreshSelect = panel.querySelector("#vto-v4-refresh");
    minHoursInput = panel.querySelector("#vto-v4-min-hours");
    startAfterSelect = panel.querySelector("#vto-v4-start-after");
    activityEl = panel.querySelector("#vto-v4-activity");

    armBtn.addEventListener("click", () => state.armed ? disarm() : arm());
    pauseBtn.addEventListener("click", togglePause);
    panel.querySelector("#vto-v4-scan").addEventListener("click", () => {
      addLog("Manual scan");
      scan();
    });

    autoBtn.addEventListener("click", async () => {
      await storageSet({ autoConfirm: !state.autoConfirm });
      updatePanel();
      scan();
    });

    testBtn.addEventListener("click", async () => {
      await storageSet({ testMode: !state.testMode });
      updatePanel();
      addLog(`Test Mode ${state.testMode ? "ON" : "OFF"}`);
    });

    soundBtn.addEventListener("click", async () => {
      await storageSet({ soundEnabled: !state.soundEnabled });
      updatePanel();
      if (state.soundEnabled) beep(800, .08);
    });

    notifyBtn.addEventListener("click", async () => {
      await storageSet({ notificationsEnabled: !state.notificationsEnabled });
      updatePanel();
    });

    flashBtn.addEventListener("click", async () => {
      await storageSet({ tabFlashEnabled: !state.tabFlashEnabled });
      if (!state.tabFlashEnabled) stopTitleFlash();
      updatePanel();
    });

    longestBtn.addEventListener("click", async () => {
      await storageSet({ preferLongest: !state.preferLongest });
      updatePanel();
      scan();
    });

    refreshSelect.addEventListener("change", async () => {
      const seconds = Math.max(5, Number(refreshSelect.value) || 5);
      await storageSet({ refreshSeconds: seconds });
      panel.querySelector("#vto-v4-interval-label").textContent = `${seconds}s`;
      addLog(`Refresh set to ${seconds}s`);
      if (state.armed && !state.paused) startRefresh();
      updatePanel();
    });

    minHoursInput.addEventListener("change", async () => {
      const value = Math.max(0, Number(minHoursInput.value) || 0);
      await storageSet({ minHours: value });
      addLog(`Minimum hours set to ${value}`);
      scan();
    });

    startAfterSelect.addEventListener("change", async () => {
      await storageSet({ startAfter: startAfterSelect.value });
      addLog(`Start-after filter changed`);
      scan();
    });

    panel.querySelector("#vto-v4-copy").addEventListener("click", copyLog);
    panel.querySelector("#vto-v4-clear").addEventListener("click", () => {
      activity = [];
      updateActivity();
    });

    panel.querySelector("#vto-v4-min").addEventListener("click", async () => {
      await storageSet({ panelMinimized: !state.panelMinimized });
      updatePanel();
    });

    makeDraggable(panel, panel.querySelector("#vto-v4-drag"));

    if (state.panelX != null && state.panelY != null) {
      panel.style.left = `${state.panelX}px`;
      panel.style.top = `${state.panelY}px`;
      panel.style.right = "auto";
      panel.style.bottom = "auto";
    }

    updatePanel();
  }

  function makeDraggable(box, handle) {
    let dragging = false;
    let dx = 0;
    let dy = 0;

    handle.addEventListener("mousedown", e => {
      if (e.target.closest("button")) return;
      dragging = true;
      const rect = box.getBoundingClientRect();
      dx = e.clientX - rect.left;
      dy = e.clientY - rect.top;
      e.preventDefault();
    });

    document.addEventListener("mousemove", e => {
      if (!dragging) return;

      const maxX = Math.max(0, window.innerWidth - box.offsetWidth);
      const maxY = Math.max(0, window.innerHeight - 40);
      const x = Math.min(maxX, Math.max(0, e.clientX - dx));
      const y = Math.min(maxY, Math.max(0, e.clientY - dy));

      box.style.left = `${x}px`;
      box.style.top = `${y}px`;
      box.style.right = "auto";
      box.style.bottom = "auto";
    });

    document.addEventListener("mouseup", async () => {
      if (!dragging) return;
      dragging = false;
      const rect = box.getBoundingClientRect();
      await storageSet({
        panelX: Math.round(rect.left),
        panelY: Math.round(rect.top)
      });
    });
  }

  function startRuntimeClock() {
    setInterval(() => {
      if (runtimeEl) runtimeEl.textContent = durationText(Date.now() - startedAt);
    }, 1000);
  }

  chrome.storage.onChanged.addListener((changes, areaName) => {
    if (areaName !== "local") return;

    for (const [key, change] of Object.entries(changes)) {
      if (key in DEFAULTS) state[key] = change.newValue;
    }

    if (!panel) return;

    updatePanel();

    if (!state.armed) {
      stopRefresh();
      stopTitleFlash();
      setStatus("DISARMED", "off");
      return;
    }

    if (state.paused) {
      stopRefresh();
      setStatus("PAUSED", "warning");
      return;
    }

    if (!refreshTimer) startRefresh();
    scan();
  });

  async function initialize() {
    state = await storageGet();
    state.refreshSeconds = Math.max(5, Number(state.refreshSeconds) || 5);

    buildPanel();
    panel.querySelector("#vto-v4-interval-label").textContent = `${state.refreshSeconds}s`;

    const observer = new MutationObserver(() => {
      clearTimeout(scanDebounce);
      scanDebounce = setTimeout(scan, 300);
    });

    observer.observe(document.documentElement, {
      childList: true,
      subtree: true,
      characterData: true
    });

    scanTimer = setInterval(() => {
      if (!document.getElementById("vto-v4-panel")) buildPanel();
      scan();
    }, 1500);

    startRuntimeClock();

    if (state.armed && !state.paused) {
      setStatus("ARMED — watching", "armed");
      startRefresh();
    } else if (state.armed && state.paused) {
      setStatus("PAUSED", "warning");
    } else {
      setStatus("DISARMED", "off");
    }

    scan();
  }

  async function licensedBootstrap() {
    await window.VTOLicense.waitForValid();
    await initialize();

    window.VTOLicense.startWatch(async status => {
      if (state.armed) {
        await disarm("License inactive");
      }

      if (panel) {
        panel.style.display = "none";
      }

      console.warn("[VTO Watcher V4] License became inactive:", status);
    });
  }

  licensedBootstrap().catch(err => {
    console.error("[VTO Watcher V4] Licensed initialization failed", err);
  });
})();