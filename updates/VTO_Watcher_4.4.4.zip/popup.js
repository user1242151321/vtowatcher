const messageEl = document.getElementById("message");
const activateBox = document.getElementById("activateBox");
const activeBox = document.getElementById("activeBox");
const keyInput = document.getElementById("licenseKey");
const activateBtn = document.getElementById("activateBtn");
const deactivateBtn = document.getElementById("deactivateBtn");
const openBtn = document.getElementById("openBtn");
const expiresEl = document.getElementById("expires");
const labelEl = document.getElementById("licenseLabel");
const deviceEl = document.getElementById("device");
const versionAccessEl = document.getElementById("versionAccess");
const currentVersionEl = document.getElementById("currentVersion");

const updateBox = document.getElementById("updateBox");
const updateHeading = document.getElementById("updateHeading");
const updateText = document.getElementById("updateText");
const updateBtn = document.getElementById("updateBtn");
const noUpdateUrl = document.getElementById("noUpdateUrl");
const copyStepsBtn = document.getElementById("copyStepsBtn");

let currentUpdateUrl = null;

currentVersionEl.textContent = chrome.runtime.getManifest().version;

const UPDATE_STEPS = [
  "VTO Watcher manual update:",
  "1. Download the update ZIP.",
  "2. Extract it.",
  "3. Replace the files in your VTO extension folder.",
  "4. Open chrome://extensions.",
  "5. Press Reload on VTO Watcher.",
  "6. Open the extension and confirm the new version is shown."
].join("\n");

function setMessage(text, good = false) {
  messageEl.textContent = text;
  messageEl.style.background = good
    ? "linear-gradient(90deg, rgba(16,86,64,.88), rgba(18,61,84,.72))"
    : "linear-gradient(90deg, rgba(14,62,54,.85), rgba(19,47,62,.65))";
}

function formatExpiry(value) {
  if (!value) return "No expiration";
  const d = new Date(value);
  return Number.isNaN(d.getTime()) ? String(value) : d.toLocaleDateString() + " " + d.toLocaleTimeString();
}

function showUpdate(status) {
  const required =
    Boolean(status?.updateRequired) ||
    status?.reason === "update_required";

  const available =
    required ||
    Boolean(status?.updateAvailable);

  if (!available) {
    updateBox.classList.add("hidden");
    updateBox.classList.remove("required");
    currentUpdateUrl = null;
    return;
  }

  updateBox.classList.remove("hidden");
  updateBox.classList.toggle("required", required);

  updateHeading.textContent = required ? "UPDATE REQUIRED" : "UPDATE AVAILABLE";

  const parts = [];
  if (status.latestVersion) {
    parts.push(`Latest: v${status.latestVersion}.`);
  }
  if (status.updateMessage) {
    parts.push(status.updateMessage);
  } else {
    parts.push(
      required
        ? "This version has been disabled by the owner."
        : "A newer VTO Watcher version is available."
    );
  }

  updateText.textContent = parts.join(" ");
  currentUpdateUrl = status.updateUrl || null;

  updateBtn.classList.toggle("hidden", !currentUpdateUrl);
  noUpdateUrl.classList.toggle("hidden", Boolean(currentUpdateUrl));

  if (!currentUpdateUrl) {
    noUpdateUrl.textContent = "The GitHub update download is not available yet.";
  }
}

async function refreshStatus(force = true) {
  const status = await chrome.runtime.sendMessage({
    type: "licenseStatus",
    force
  });

  showUpdate(status);

  if (status.valid) {
    activateBox.classList.add("hidden");
    activeBox.classList.remove("hidden");

    setMessage(
      status.offlineGrace
        ? "License active — temporary offline grace"
        : "License active",
      true
    );

    expiresEl.textContent = formatExpiry(status.expiresAt);
    labelEl.textContent = status.label || "Active";
    deviceEl.textContent = (status.deviceId || "").slice(0, 8) || "—";

    const maxMajor = Number(status.maxMajorVersion || 4);
    versionAccessEl.textContent =
      maxMajor >= 99 ? "All future" : `Through V${maxMajor}`;
  } else {
    activeBox.classList.add("hidden");
    activateBox.classList.remove("hidden");

    if (status.reason === "setup_required") {
      setMessage("Owner setup required: configure the license server URL.");
    } else if (status.reason === "expired") {
      setMessage("License expired");
    } else if (status.reason === "update_required") {
      setMessage(status.message || "Update required");
    } else if (status.reason === "version_not_allowed") {
      setMessage(status.message || "This license does not include this version");
    } else {
      setMessage(status.message || "This device has not been activated.");
    }
  }
}

activateBtn?.addEventListener("click", async () => {
  const key = keyInput.value.trim();

  if (!key) {
    setMessage("Enter a license key.");
    return;
  }

  activateBtn.disabled = true;
  activateBtn.textContent = "Activating…";
  setMessage("Activating…");

  try {
    const result = await chrome.runtime.sendMessage({
      type: "activateLicense",
      key
    });

    showUpdate(result);

    if (!result.ok || !result.valid) {
      setMessage(result.message || "Activation failed.");
      return;
    }

    keyInput.value = "";
    await refreshStatus(false);
  } finally {
    activateBtn.disabled = false;
    activateBtn.textContent = "Activate";
  }
});

keyInput?.addEventListener("keydown", event => {
  if (event.key === "Enter") activateBtn.click();
});

deactivateBtn?.addEventListener("click", async () => {
  deactivateBtn.disabled = true;
  deactivateBtn.textContent = "Deactivating…";
  setMessage("Deactivating…");
  try {
    await chrome.runtime.sendMessage({ type: "deactivateLicense" });
    await refreshStatus(false);
  } finally {
    deactivateBtn.disabled = false;
    deactivateBtn.textContent = "Deactivate";
  }
});

openBtn?.addEventListener("click", () => {
  chrome.tabs.create({ url: "https://atoz.amazon.work/" });
});

updateBtn?.addEventListener("click", () => {
  if (!currentUpdateUrl) return;
  chrome.tabs.create({ url: currentUpdateUrl });
});

copyStepsBtn?.addEventListener("click", async () => {
  try {
    await navigator.clipboard.writeText(UPDATE_STEPS);
    copyStepsBtn.textContent = "Copied";
    setTimeout(() => {
      copyStepsBtn.textContent = "Copy update steps";
    }, 1500);
  } catch (_) {
    copyStepsBtn.textContent = "Could not copy";
  }
});

refreshStatus(true).catch(err => {
  setMessage(`License check failed: ${err.message || err}`);
});