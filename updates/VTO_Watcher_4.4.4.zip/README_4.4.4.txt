VTO Watcher 4.4.4

- current rounded popup and watcher GUI
- balanced license details with no LIVE badge in the license popup
- persistent runtime across VTO navigation
- soft A to Z refresh flow and hard-reload protection
- live-offer action handling from v4.3.4
- Cloudflare license validation + GitHub update feed

Install/update:
1. Extract this ZIP to a permanent folder.
2. Open chrome://extensions.
3. Enable Developer mode.
4. Load unpacked (or reload your existing VTO Watcher) using this folder.
