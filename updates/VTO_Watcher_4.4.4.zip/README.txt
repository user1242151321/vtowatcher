VTO Watcher 4.2.5

Updates are checked from GitHub. When a newer version is available, the extension shows an update notice and DOWNLOAD UPDATE opens the GitHub-hosted ZIP. Cloudflare remains the license backend.
