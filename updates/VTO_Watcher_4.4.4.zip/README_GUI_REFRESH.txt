VTO Watcher 4.2.6

- Refreshed dark neon popup UI matching the website design
- New green V extension icon
- GitHub-hosted update downloads preserved
- Cloudflare license validation preserved
